# 📌 Desafio: Copiloto com Fluxo de Conversa Personalizado – Microsoft Copilot Studio

Este repositório contém o resumo do aprendizado ao criar um **Copiloto com fluxo de conversa personalizado** no Microsoft Copilot Studio, conforme solicitado no desafio prático.

---

## 🚀 Resumo do que aprendi

Durante a prática, explorei o Microsoft Copilot Studio para criar um **fluxo de conversa personalizado**, entendendo como construir tópicos, variáveis, entidades e respostas generativas, criando interações inteligentes e adaptadas às necessidades do usuário.

---

## 🧠 Principais Aprendizados

### 🔹 1. Criando um Copiloto
- Criação de um novo agente do zero.
- Configuração de idioma, nome e objetivo do copiloto.
- Definição do tom e da personalidade do agente.

### 🔹 2. Estrutura do Fluxo de Conversa
- **Tópicos**: blocos de conversa que determinam respostas do copiloto.
- **Ramificações**: caminhos diferentes baseados nas respostas do usuário.
- **Tópicos de fallback**: usados quando o chatbot não entende a entrada do usuário.

### 🔹 3. Entidades e Variáveis
- **Entidades**: capturam informações específicas do usuário.
- **Variáveis**: armazenam essas informações para uso posterior no fluxo.
- **Tipos de variáveis**: texto, número, data.
- **Variáveis globais**: podem ser usadas em múltiplos tópicos.

### 🔹 4. Respostas Generativas
- Criação de respostas automáticas pela IA com base no contexto e nas **Knowledge Sources**.
- Uso de prompts bem definidos para orientar a IA.
- Parâmetros como **temperatura** e **top-p** para controlar a criatividade e diversidade das respostas.

### 🔹 5. Integrações e Boas Práticas
- Conectar a **Power Automate** para automatizar tarefas.
- Utilizar **AI Builder** para IA personalizada.
- Testar sempre tópicos, entidades, variáveis e respostas antes de publicar.
- Organizar tópicos complexos em fluxos menores e claros.

---

## 📂 Conteúdo do Repositório
- **README.md** → Resumo do aprendizado e principais práticas.
- **prints/** → Capturas de tela do Copiloto (opcional).
- **exemplos/** → Arquivos exportados do Copiloto (opcional).

---

## 🔗 Documentação Oficial
Para aprofundar meus estudos:  
[Microsoft Copilot Studio](https://learn.microsoft.com/pt-br/microsoft-copilot-studio/)

---

## 🎯 Conclusão
Este desafio permitiu criar um **Copiloto com fluxo de conversa personalizado**, entendendo tópicos, ramificações, variáveis, entidades e respostas generativas, proporcionando experiências interativas, inteligentes e adaptadas aos usuários.
